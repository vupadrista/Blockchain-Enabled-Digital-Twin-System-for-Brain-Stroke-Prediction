const express = require('express')
require('dotenv').config({path: '.env'})
const cors = require('cors')
const Web3 = require('web3')
const es = require("./db.js");
var randomstring = require("randomstring");

const app = express()
app.use(cors());
app.use(express.json())

const DeployedContract = require('./artifacts/contracts/Fusion.sol/Fusion.json')
// This account will send all the transactions, Master Account
const address_1 = process.env.ACCOUNT_ADDRESS_1
const address_2 = process.env.ACCOUNT_ADDRESS_2
// Master Account's private key
const privateKey_1 = process.env.PRIVATE_KEY_GANACHE_1
const privateKey_2 = process.env.PRIVATE_KEY_GANACHE_2

//Currently running a Datahub Node, can be later changed to infura node or can run own node as well.
const DeployedContractAddress_1 = process.env.DEPLOYED_CONTRACT_ADDRESS_1
const DeployedContractAddress_2 = process.env.DEPLOYED_CONTRACT_ADDRESS_2

const nodeEndpointUrl_1 = process.env.NODE_URL1
const nodeEndpointUrl_2 = process.env.NODE_URL2

const web3_1 = new Web3(nodeEndpointUrl_1)
const contract_1 = new web3_1.eth.Contract(
    DeployedContract.abi,
    DeployedContractAddress_1
)

const web3_2 = new Web3(nodeEndpointUrl_2)
const contract_2 = new web3_2.eth.Contract(
    DeployedContract.abi,
    DeployedContractAddress_2
)


const network = async (contractInterface, req, web3, address, privateKey) => {
  let tx = contractInterface.methods.saveData(req.body.pID, [req.body.temp||0, 
    [req.body.humidity||0, req.body.daiBP || 0]]) // sysBP
  
  const gas = await tx.estimateGas({from: address})
  const gasPrice = await web3.eth.getGasPrice()
  const data = tx.encodeABI()
  const nonce = await web3.eth.getTransactionCount(address)
  const signedTx = await web3.eth.accounts.signTransaction(
      {
          to: contractInterface.options.address,
          data,
          gas,
          gasPrice,
          nonce,
          chainId: 1337
      },
      privateKey
  )
  const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction)
  return receipt
}


const getDataFromHash = async (txHash, web3) => {
  // console.log(txHash)
  result = await web3.eth.getTransaction(txHash)
  // console.log("result:::", result)
  let encodedInput = result.input
  const decodedDataFrame = [{
      type: 'uint256',
      name: 'decodedPID'
  }, {
      type: 'uint256',
      name: 'decodedTemp'
  }, {
      type: 'uint256',
      name: 'decodedSystolicBP'
  }, {
      type: 'uint256',
      name: 'decodedDiastolicBP'
  }]
  const decodedData = web3.eth.abi.decodeParameters(decodedDataFrame, `0x${encodedInput.substring(10)}`)
  return decodedData
}


const pushToElasticSearch = async (req, patientData) => {
  console.log("Patienti data just before adding into elastic search: ", patientData)
  await es.bulkIndex("patients", [
    {
      patient_id: patientData.decodedPID,
      temperature: patientData.decodedTemp,
      systolic_bp: 0, // patientData.decodedSystolicBP,
      diastolic_bp: patientData.decodedDiastolicBP,
      humidity: patientData.decodedSystolicBP,
      // first: req.first,
      // second: req.second, 
      // third: req.third, 
      // remarks: req.remarks, 
      // disease: req.disease,
      created_on: +new Date(),
      sensor_ts: req.sensor_ts,
      network: req.network,
      txhash: req.txHash,
      cid: req.cid,
    }
  ])
}


app.post("/saveData", async function(req, res){
  console.log(req.body, "=============== ", req.originalUrl)
  let cid = randomstring.generate(256), patientData_1, error = false, errmsg, tempnetwork;

  try{
    const receipt_1 = await network(contract_1, req, web3_1, address_1, privateKey_1);
    const txHash_1 = receipt_1.transactionHash;

    patientData_1 = await getDataFromHash(txHash_1, web3_1)
    await pushToElasticSearch(
      {
        txHash: txHash_1,
        network: "ganache1",
        cid: cid,
        ...req.body
      }
    , patientData_1)
  }catch(e){
    console.log("First call SAVE DATA:", e)
    error = true
    errmsg = "Blockchain Network: ganache1 is down or not running. "
    tempnetwork = "ganache2"
  }
  
  try{
    const receipt_2 = await network(contract_2, req, web3_2, address_2, privateKey_2)
    const txHash_2 = receipt_2.transactionHash;

    patientData_1 = await getDataFromHash(txHash_2, web3_2)
    await pushToElasticSearch({
        txHash: txHash_2,
        network: "ganache2",
        cid: cid, 
        ...req.body
      }, 
    patientData_1)

  }catch(e){
    console.log("Second call SAVE DATA:", e)

    if (error){
      return res.send({
        error: true,
        msg: errmsg +  "Blockchain Network: ganache2 is down or not running. Unable to Add data on blockchain and databases."
      })  
    }

    error = true
    errmsg = "Blockchain Network: ganache2 is down or not running."
    tempnetwork = "ganache1"
  }
  
  res.send({
    error: error,
    msg: error ? 
      errmsg + ` Added Data into blockchain network: ${tempnetwork}` : `Added Data into both blockchain networks`,
  })

})


app.post("/getData", async function(req, res){
  console.log("getData ... ", req.originalUrl, req.body)
  console.log("================ FETCH DATA BP=======================")

  let patientid = req.body.patientId,
    network = req.body.network || "ganache1",
    results =  await es.search_within_multiple_fields("patients", 
      ["patient_id", "network", "temperature"],  // column in elastic search
      [patientid, network],
      ["temperature", "humidity"]
    );
  // we will have replica or 2 data points with different txhashes and network
  // so pick only one network, by default ganache1
  let data1= results[0];
  console.log("Data check ..... ", data1)

  if (data1){
    let res1 = await verifyDataPoints(data1, "all");
    console.log("verify data check: ", res1)
    if (res1.bc_error){
      console.log("Looks like blockchain is down ", data1.network, " .. cache miss")
      return []
    }
  }

  results = results.map(x => {
    var date = new Date(x.sensor_ts || x.created_on).toISOString()
    x.date = date.slice(0,10)
    x.time = date.slice(11, 19)
    return x
  })
  console.log(results)

  res.send(results)
})


app.post("/getData/bp", async function(req, res){
  console.log("getData dp... ", req.originalUrl, req.body)
  console.log("================ FETCH DATA BP=======================")
  let patientid = req.body.patientId,
    network = req.body.network || "ganache1",
    results =  await es.search_within_multiple_fields("patients", 
      ["patient_id", "network", "diastolic_bp"],  // column in elastic search
      [patientid, network, 0],
      ["diastolic_bp"]
    );
  // we will have replica or 2 data points with different txhashes and network
  // so pick only one network, by default ganache1
  let data1= results[0];
  if (data1){
    let res1 = await verifyDataPoints(data1, "all");
    if (res1.bc_error){
      console.log("Looks like blockchain is down for bp", data1.network, " .. cache miss")
      return []
    }
  }

  results = results.map(x => {
    var date = new Date(x.sensor_ts||x.created_on).toISOString()
    x.date = date.slice(0,10)
    x.time = date.slice(11, 19)
    return x
  })
  console.log(results)
  res.send(results)
})


let verifyDataPoints = async(db_data, sensor="all") => {
  let patientData;
  if (!db_data){
    return {
      verify: false,
      nodata: true,
      msg: `Verification failed, No data found.`  
    } 
  }

  if (db_data.network == "ganache1"){
    try{
      patientData = await getDataFromHash(db_data.txhash, web3_1);
    }catch(e){
      console.log("First call VERIFY DATA:", e)

      return {
        verify: false,
        bc_error: true,
        msg: `Blockchain Network: ${db_data.network} is either stopped running or unable to connect via internet`
      }
    }
  }else if (db_data.network == "ganache2"){
    try{
      patientData = await getDataFromHash(db_data.txhash, web3_2);
    }catch(e){
       console.log("Second call VERIFY DATA:", e)

        return {
          verify: false,
          bc_error: true,
          msg: `Blockchain Network: ${db_data.network} is either stopped running or unable to connect via internet`
        }
      }
  }

  let data = {
    patient_id: patientData.decodedPID,
    temperature: patientData.decodedTemp,
    humidity: patientData.decodedSystolicBP,
    diastolic_bp: patientData.decodedDiastolicBP,
  };

  console.log(data, db_data, sensor)


  if (sensor == "all"  && +data.temperature == +db_data.temperature && 
    +data.humidity == +db_data.humidity){
    console.log("ALLL ............. ")
    return {
      verify: true,
      txhash: db_data.txhash,
      data: data.temperature,
      msg: `Verified on Blockchain Network: ${db_data.network}, transaction hash: ${db_data.txhash}, data: ${data.temperature}, all sensors data verififed`
    }
  }

  console.log("===============", data[sensor], db_data[sensor], sensor)


  if (data[sensor] == db_data[sensor]){
    return {
      verify: true,
      txhash: db_data.txhash,
      data: db_data[sensor],
      network: db_data.network,
      msg: `Verified success on Blockchain Network: ${db_data.network}, transaction hash: ${db_data.txhash}, data: ${data[sensor]}, ${sensor} Sensor`
    }
  }

  return {
    verify: false,
    msg: `Verification failed on Blockchain Network: ${db_data.network}, transaction hash: ${db_data.txhash}, data: ${data.temperature}, ${sensor} Sensor`

  }

}


app.post("/verify", async function(req, res){
  console.log("================= DATA VERIFICATION URL ===============: ", req.body)
  let id = req.body.cid, sensor = req.body.sensor,
    data = await es.search_single_feild("patients", "cid", id);
  
    console.log("DATA from ES: ", data)
  let res1 = await verifyDataPoints(data[0], sensor || "all"),
     res2 = await verifyDataPoints(data[1], sensor || "all");

  console.log(res1, res2)

  if (res1.nodata && res2.verify){
    let tempnetwork = "ganache1";
    if (res2.network == "ganache1")
      tempnetwork ="ganache2"
    
    res1.msg += ` Data is not found in blockchain network: ${tempnetwork}`
  }else if (res2.nodata && res1.verify){
    let tempnetwork = "ganache1";
    if (res1.network == "ganache1")
      tempnetwork ="ganache2"
    
    res2.msg += ` Data is not found in blockchain network: ${tempnetwork}`
  }

  res.send({
    data: data,
    network: [res1, res2],
    verify: res1.verify && res2.verify
  })
  
})


app.post("/risk", async function(req, res){
  console.log("risk data ... ", req.originalUrl, req.body)
  let patientid = req.body.patientId,
    results =  await es.search_within_multiple_fields("patients", 
      ["patient_id", "network", "temperature"],  // column in elastic search
      [patientid, "ganache1", 0],       
      ["temperature", "humidity"],
      1
    );

  results = results[0]

  let results2 =  await es.search_within_multiple_fields("patients", 
      ["patient_id", "network", "diastolic_bp"],  // column in elastic search
      [patientid, "ganache1", 0],
      ["diastolic_bp"],
      1
    ), risk_data = {
      error: true,
      msg: "No Data Available to compute risk and advice docter"
    };
  
  results2 = results2[0]
  console.log("risk data from elastic search .... ", results, results2)

  if (results2 && results){
    var risk=false;
    if (+results2.diastolic_bp > 120 && +results.temperature >= +process.env.MAX_TEMPETATURE 
        && +results.humidity >= +process.env.MAX_HUMIDITY){
      risk = true
      risk_data = {
        risk: true,
        temperature: +results.temperature,
        bp: +results2.diastolic_bp,
        humidity: +results.humidity,
        error: false,
        msg: "Based on the readings and Past history, User Peter Owen, may be at risk for Heart Attack"
      }
    }else{
      risk_data = {
        risk: false,
        temperature: +results.temperature,
        bp: +results2.diastolic_bp,
        humidity: +results.humidity,
        error: false,
        msg: "Based on the readings, User Peter Owen, is Normal"
      }

    }
  }

  res.send(risk_data)
})


app.listen({
  host: process.env.EXPRESS_IP, 
  port: process.env.EXPRESS_PORT}, () => {
    console.log("Elastic Search server is up and running...")
});
