# Sample Hardhat Project

This project demonstrates a basic Hardhat use case. It comes with a sample contract, a test for that contract, and a script that deploys that contract.

Try running some of the following tasks:

```shell
npx hardhat help
npx hardhat test
GAS_REPORT=true npx hardhat test
npx hardhat node
npx hardhat run scripts/deploy.js
npx hardhat run scripts/deploy.js --network rinkeby
```

Contract address: 0x639DE86737764a2457987Ae89656B826a128d1Dd
deployed 24-7-2022 21:04
DataHub Node, Rinkeby Testnet