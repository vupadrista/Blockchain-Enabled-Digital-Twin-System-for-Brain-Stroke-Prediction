require("@nomicfoundation/hardhat-toolbox");
require('dotenv').config({path: '.env'});

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  networks: {
    localhost: {
      url: "http://127.0.0.1:8545"
    },
    ganache1: {
      url: "http://127.0.0.1:7545/",
      accounts: [process.env.PRIVATE_KEY_GANACHE_1]
    },
    ganache2: {
      url: "http://127.0.0.1:7546/",
      accounts: [process.env.PRIVATE_KEY_GANACHE_2]
    }
  },
  solidity: "0.8.9",
};
