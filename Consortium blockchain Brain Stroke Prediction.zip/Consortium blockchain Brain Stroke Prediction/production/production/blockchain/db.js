const elasticsearch = require('elasticsearch')
const esClient = new elasticsearch.Client({
  host: 'http://127.0.0.1:9200', 
  // user host paramter to connect to remote
});


// deleting indexes
module.exports.delete_index = delete_index = async function(index) {
  return new Promise((resolve, reject) => {
    esClient.indices.delete({
      index: index 
      }, function(err, res) {
          if (err) {
            resolve(false)
            console.error(err.message);
            // Connect to logger function later
          } else {
            resolve(true)
            console.log('Indexes have been deleted!');
          }
      });
  });
}


//script to create index with required datatype 
module.exports.create_index = create_index = function () {
  let dataype1  = {};
  dataype1 =  {
    "patient_id": { type: "text"},
    "temperature": { type: "float"},
    "systolic_bp": { type: "float"},
    "diastolic_bp": { type: "float"},
    "humidity": { type: "float"},
    "created_on": {type: "long"},
    "sensor_ts": {type: "text"},
    "first": {type: "text"},
    "second": {type: "text"},
    "third": {type: "text"},
    "remarks": {type: "text"},
    "disease": {type: "text"},
    "txhash": {type: "text"},
    "network": {type: "text"},
    "cid": {type: "text"},

  };
  console.log("============== creating index ", dataype1)

  return new Promise((resolve, reject) => {
    // returns Promise
    esClient.indices.create({
      index: "patients",
      body: {
        mappings: {
          properties:  dataype1
        }
      }
    }, 
      { ignore: [400]}
    ).then(r => {
      console.log("Index result : ", r)
      resolve(true)
    })
    .catch(e => {
      // throws error if index already exists due to index id clash
      // logger here
      resolve(false)
    })
  });

}

// delete_index("patients")
// create_index()


module.exports.bulkIndex = bulkIndex =function (index, data, uid="id") {
  let bulkBody = [];
  console.log("Bulk indexing ..... ")
    data.forEach(item => {
      bulkBody.push({
        index: {
          _index: index,
          _id: item[uid]  // unique id in the json data point
          // id is optional, if no id is sent, elastic search
          // will randomly create uuid using flakeID algorithm
          // and add the _id for each data point for document
        }
      });
      // Add index details first, followed by the actual data point
      bulkBody.push(item);
    });
  
  // Final array looks like [ <INDEX DATA>, <JSON1>, <INDEX DATA>, <JSON2> , ...]
  return new Promise((resolve, _) => {
       esClient.bulk({refresh :true, body: bulkBody})
        .then(results => {
          console.log("bulk operation success ...")
          resolve(results)
        })
        .catch((e) => {
          // logg
          console.log("Elastic search result error: ", e)
          resolve(null)
        });
    });

};


function get(index, id){
  return esClient.get({index: index, id: id});
}


// get JSON doucment from ID
module.exports.get_document = get_document =  function(index_name ,id) {

    console.log(`retrieving document from ${index_name}  whose id is ${id} .`);

    return new Promise((resolve, _) => {
       get(index_name, id)
        .then(results => {
          if (results && results._source){
            results._source.id = results._id
            resolve(results._source)
          }
        })
        .catch((e) => {
          // logg
          resolve(null)
        });

    })
};


function search(index, body) {
  return esClient.search({index: index, body: body});
};


module.exports.search_single_feild  = search_single_feild = async function(
    index_name, col, value) { 
    let body = {
      size: 20,
      from: 0,
      sort: {
        "created_on": {
          order: "desc"
        }
      },
      query: {
        match: {
          [col]: value, 
        }
      },
    };

    let results = await new Promise((resolve, _) => {
       search(index_name, body)
        .then(results => {
          resolve(results)
        })
        .catch((e) => {
          // logg
          resolve(null)
        });

    }), output = [];
    // console.log(results)

    if (results){
      results.hits.hits.forEach((hit, index) => {
        if (hit && hit._source){
          hit._source.id = hit._id
          hit._source.index = index
        }

        output.push(hit._source)
      });
    }

    return output

};


module.exports.search_within_multiple_fields  = search_within_multiple_fields = async function(
  index_name, col, value, feilds=[], limit=100) { 
  let body = {
    size: limit,
    from: 0,
    _source: ["cid", "patient_id", "sensor_ts" , "created_on", "network", "txhash", ...feilds],
    sort: {
      "created_on": {
        order: "desc"
      }
    },
    query: {
      bool:{
        must: [
          {
            match: {
              [col[0]]: value[0], 
            }
          },
          {
            match: {
              [col[1]]: value[1], 
            }
          },
          {
            range: {
              [col[2]]: {
                gt: 0
              }
            }
          }
        ]
      }
    },
  };

  let results = await new Promise((resolve, _) => {
     search(index_name, body)
      .then(results => {
        resolve(results)
      })
      .catch((e) => {
        // logg
        resolve(null)
      });

  }), output = [];
  // console.log(results)

  if (results){
    results.hits.hits.forEach((hit, index) => {
      if (hit && hit._source){
        hit._source.id = hit._id
        hit._source.index = index
      }

      output.push(hit._source)
    });
  }

  return output

};


if (process.argv[1] == "deploy"){
  this.create_index()
}
