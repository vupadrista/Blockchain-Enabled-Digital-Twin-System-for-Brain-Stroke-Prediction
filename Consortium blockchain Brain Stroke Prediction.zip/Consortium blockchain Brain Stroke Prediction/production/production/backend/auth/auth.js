const jwt = require("jsonwebtoken");
const path = require("path");


require("dotenv").config({ path: path.resolve(__dirname, "./.env") });


// Target url
// http:14.99.139.180:8085/restapi/iot/sensors/v1.0/:vendor/:sensor/:token/send
// Token:
// eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdXRoIjp0cnVlLCJ2ZXJzaW9uIjoidjEiLCJ2ZW5kb3IiOiJzaWdmb3giLCJvcmdpZCI6IkpzblQxMkJ1OTFRYWRTcTgiLCJlbWFpbCI6InZzbWFoaWRoYXJAZ21haWwuY29tIiwicmVzdGFwaSI6dHJ1ZSwic2Vuc29yIjoic2lnZm94LXRlbXAtc2Vuc29yIiwidXJsIjoiL3Jlc3RhcGkvaW90L3NlbnNvcnMvdjEuMCIsImlhdCI6MTY2NDM0OTU4OSwiZXhwIjoxNjk1ODg1NTg5fQ.ROvc3jdiXbdNh1fe0hTyN4_uFMgy9gc6_rRr-N4CY7U
// http:14.99.139.180:8085/restapi/iot/sensors/v1.0/sigfox-temp-sensor/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdXRoIjp0cnVlLCJ2ZXJzaW9uIjoidjEiLCJ2ZW5kb3IiOiJzaWdmb3giLCJvcmdpZCI6IkpzblQxMkJ1OTFRYWRTcTgiLCJlbWFpbCI6InZzbWFoaWRoYXJAZ21haWwuY29tIiwicmVzdGFwaSI6dHJ1ZSwic2Vuc29yIjoic2lnZm94LXRlbXAtc2Vuc29yIiwidXJsIjoiL3Jlc3RhcGkvaW90L3NlbnNvcnMvdjEuMCIsImlhdCI6MTY2NDM0OTU4OSwiZXhwIjoxNjk1ODg1NTg5fQ.ROvc3jdiXbdNh1fe0hTyN4_uFMgy9gc6_rRr-N4CY7U/send


let generateAccessToken = function(payload, secret, expiry){
    // for on premise or company cloud, use the company's jwt secret to sign the key
    // secret is null/undefined when they consider our own cloud  
    return jwt.sign(payload, secret || SENSOR_API_SECRET, {
      expiresIn: expiry || process.env.JWT_EXPIRY_TOKEN,
    });
}


const SENSOR_API_SECRET = process.env.SENSOR_API_SECRET;
const ADMIN_API_SECRET = process.env.ADMIN_API_SECRET;


module.exports.auth = async(req, res, next)=>{
  let token = req.params.token; 
  console.log(token)
  /**
   * 
   * 
   * 
   * 
   * Payload: { 
      auth: true, 
      version: "v1",
      vendor: "sigfox",
      orgid: "JsnT12Bu91QadSq8",
      email: "vsmahidhar@gmail.com",
      restapi: true,
      sensor: "sigfox-temp-sensor", // can be ignored completely
      url: "/restapi/iot/sensors/v1.0"
    }
   */
  jwt.verify(token, SENSOR_API_SECRET, async (err, jwt_data) => {
    console.log(err)
    if (!err) {
      console.log("Auth access")
      req.body.url = {
        sensor: req.params.sensor,
        vendor: req.params.vendor, 
      }

      return next()
    }else{
      return res.status(403).send("Unauthorised User or Token Invalid");
    }
  });

}


module.exports.auth_api = async(req, res, next)=>{
    console.log(req.originalUrl, req.body)
    
    let token = req.headers["authorization"].slice(7);
    console.log(token)

    jwt.verify(token, ADMIN_API_SECRET, async (err, jwt_data) => {
      console.log(err)
      if (!err) {
        console.log("Auth access")  
        return next()
      }else{
        return res.status(403).send("Unauthorised User or Token Invalid");
      }
    });
  
}
  
module.exports.login = function (req, res){
    let email = req.body.email,
        passwd = req.body.password;

    if (email == "testuser@gmail.com"){
        if (passwd == "QWERTY1234!!@@##"){
            return res.send({
                token: generateAccessToken({
                    user: "testuser@gmail.com"
                }, process.env.ADMIN_API_SECRET, "3h"),
                msg: "Login Successfull",
                error: false,
            })
        }
    }

    return res.send({
        msg: "Invalid UserName or Password",
        error: true,
    })
}
