const express = require('express');
const router = express.Router();
const master = require('../controller/master');
const auth = require("../auth/auth")


router.post('/login', auth.login);
router.post('/getData', auth.auth_api, master.get_data);
router.post('/getData/bp', auth.auth_api, master.get_data_bp);
router.post('/verify', auth.auth_api, master.verify_data);
router.post('/addData', auth.auth_api, master.add_data);
router.post('/risk', auth.auth_api, master.risk);

router.post('/sensors/v1.0/:vendor/:sensor/:token/send', auth.auth, master.sensor_restapi);

module.exports = router;
