self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0307d3e174e2f2b2d99ed6f16630e257",
    "url": "/index.html"
  },
  {
    "revision": "72220e9e8c2783546c63",
    "url": "/static/css/2.d9ad5f5c.chunk.css"
  },
  {
    "revision": "b91745033a05eef5d954",
    "url": "/static/css/main.cac33e04.chunk.css"
  },
  {
    "revision": "72220e9e8c2783546c63",
    "url": "/static/js/2.c104ac5d.chunk.js"
  },
  {
    "revision": "0bf38cf6c0b51ec69d7a52e8875a6dbf",
    "url": "/static/js/2.c104ac5d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b91745033a05eef5d954",
    "url": "/static/js/main.829e732d.chunk.js"
  },
  {
    "revision": "f468c674e9fbf1a2a280",
    "url": "/static/js/runtime-main.6b245b03.js"
  },
  {
    "revision": "298645a162c21ea4ab7c83f8672097a4",
    "url": "/static/media/loading_small.298645a1.gif"
  },
  {
    "revision": "4ae50d15c370a11939a24fed485a2867",
    "url": "/static/media/logo_gif.4ae50d15.gif"
  },
  {
    "revision": "45939c5a7011336d906b21c7cabbb8ad",
    "url": "/static/media/nodata.45939c5a.png"
  },
  {
    "revision": "cab2d946a9d4e88e8e791418f1ad7158",
    "url": "/static/media/transparent-blockchain-icon.cab2d946.png"
  },
  {
    "revision": "9111c2697ae99521a6ac67695729f99d",
    "url": "/static/media/traqez.9111c269.png"
  }
]);