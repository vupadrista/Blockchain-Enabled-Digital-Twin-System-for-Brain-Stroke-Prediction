const path = require("path");
const urlparse = require("url");
const debug_log = require("debug")("iot:express");
const axios = require("axios");
const { pid } = require("process");
const { time } = require("console");


require("dotenv").config({ path: path.resolve(__dirname, "./.env") });


let cache = {};


module.exports.sensor_restapi = async (req, res) => {
    /**
   * Data point:
   * {
        {\n      "messageId": "633424603962591d33ce4530",\n      "receivedAt": "Wed Sep 28 2022 10:39:25 GMT 0000 (Coordinated Universal Time)",\n      "deviceId": "633050354d64fe15346c69cf",\n      "sigfoxId": "B44613",\n      "deviceName": "Prototype 1",\n      "payload": "ee096b73",\n      "value": "57.5",\n      "sensor": "humidity",\n      "state": "",\n      "events": ""\n}': '' 
      }
   */
    debug_log("Sensor Data: ", req.body)

    let json = {}, data, patentId=17192101;

    for (let [key, _] of Object.entries(req.body)){
        if (key.includes("SenseIt")){
        console.log(key)
        let [, sensor, , value, time] = key.split("@");
        json.sensor = sensor
        json.value = value
        json.time = time 
        data = key 
        }
        
    }

    if (!cache[patentId])
        cache[patentId] = {}
    
    cache[patentId][json.sensor] = json

    // console.log("JSON parsed: ", json)

    if (Object.keys(cache[patentId]).length == 2){
        let humidity = cache[patentId]["humidity"].value,
        temp = cache[patentId]["temperature"].value,
        bodyParameters = {
            pID: patentId,
            temp: parseInt(temp), 
            humidity: parseInt(humidity),
            sensor_ts: cache[patentId]["temperature"].time,
        };

        debug_log("Both temperature and humidity sensor data reached, putting request to blockchain networks ", cache, cache[patentId])
        // return  res.status(200).send("ok")

        try{
            // put on the request
            console.log("putting the axios request now  ... ", 
                process.env.BLOCKCHAIN_URL1, bodyParameters)
            
            let bc_res = await axios.post(
                urlparse.resolve(process.env.BLOCKCHAIN_URL1, "/saveData"),
                bodyParameters, {});
            if (bc_res.data){
                let data = bc_res.data;
                // Resposne from the remote end point
                // data is json sent
                console.log("Axios response: ", data)
            }
        }catch(e){
            console.log("axios error")
            // axiox error
            if(e.response){
                if (e.response.status){
                    console.log("Error Code: ", e.response.status)
                }
            }else
                console.log(e)
        }
        

        delete cache.patentId
    }

    return res.status(200).send("ok")
};


module.exports.get_data = async (req, res) => {
    let pid = req.body.pid;
    // connect to elastic search and integrate
    // or put axios request
    try{
        // put on the request
        console.log("putting the axios request now  ... ", process.env.BLOCKCHAIN_URL1)
        console.log(urlparse.resolve(process.env.BLOCKCHAIN_URL1, "/getData")        )

        let bc_res = await axios.post(
            urlparse.resolve(process.env.BLOCKCHAIN_URL1, "/getData"),
            {
                patientId: pid,
                network: req.body.network,
            }, {});

        if (bc_res.data){
            let data = bc_res.data;
            // Resposne from the remote end point
            // data is json sent
            // console.log("Axios response .... ", data)
            return res.send(data)

        }
    }catch(e){
        console.log("axios error")
        // axiox error
        if(e.response){
            if (e.response.status){
                console.log("Error Code: ", e.response.status)
            }
        }else
            console.log(e)

        res.send([])
    }
}


module.exports.get_data_bp = async (req, res) => {
    let pid = req.body.pid;
    // connect to elastic search and integrate
    // or put axios request
    try{
        // put on the request
        console.log("putting the axios request now  ... ", process.env.BLOCKCHAIN_URL1)
        console.log(urlparse.resolve(process.env.BLOCKCHAIN_URL1, "/getData/bp")        )

        let bc_res = await axios.post(
            urlparse.resolve(process.env.BLOCKCHAIN_URL1, "/getData/bp"),
            {
                patientId: pid,
                network: req.body.network,

            }, {});

        if (bc_res.data){
            let data = bc_res.data;
            // Resposne from the remote end point
            // data is json sent
            console.log("Axios response .... ", data)
            return res.send(data)

        }
    }catch(e){
        console.log("axios error")
        // axiox error
        if(e.response){
            if (e.response.status){
                console.log("Error Code: ", e.response.status)
            }
        }else
            console.log(e)

        res.send([])
    }
}


module.exports.verify_data = async (req, res) => {
    let id = req.body.cid, sensor = req.body.sensor;
    console.log(req.body, " ......  verify_data ......")

    try{
        // put on the request
        console.log("putting the axios request now  ... ", process.env.BLOCKCHAIN_URL1)
        let bc_res = await axios.post(
            urlparse.resolve(process.env.BLOCKCHAIN_URL1, "/verify"),
            {
                cid: id,
                sensor: sensor
            }, {});

        if (bc_res.data){
            let data = bc_res.data;
            // Resposne from the remote end point
            // data is json sent
            console.log("Axios response verify.... ", data)
            return res.send(data)

        }

    }catch(e){
        console.log("axios error")
        // axiox error
        if(e.response){
            if (e.response.status){
                console.log("Error Code: ", e.response.status)
            }
        }else
            console.log(e)
        res.send(null)

    }

}


module.exports.add_data = async (req, res) => {
    try{
        // put on the request
        let bodyParameters = {
            pID: req.body.pid,
            daiBP: parseInt(req.body.value),
            sensor_ts: new Date().toISOString(),
            // first: req.body.first, 
            // second: req.body.second,
            // third: req.body.third,
            // remarks: req.body.remarks,
            // disease: req.body.disease,
        }

        console.log("putting the axios request now  ... ", 
            process.env.BLOCKCHAIN_URL1, bodyParameters)
        
        let bc_res = await axios.post(
            urlparse.resolve(process.env.BLOCKCHAIN_URL1, "/saveData"),
            bodyParameters, {});
        if (bc_res.data){
            let data = bc_res.data;
            // Resposne from the remote end point
            // data is json sent
            console.log("Axios response: ", data)
            return res.send(data)
        }
    }catch(e){
        console.log("axios error")
        // axiox error
        if(e.response){
            if (e.response.status){
                console.log("Error Code: ", e.response.status)
            }
        }else
            console.log(e)

    }
    res.send({
        error: true,
        errmsg: "Error Connecting to blockchain network or application servers, contact support team"
    })
}


module.exports.risk = async (req, res) => {
    try{
        // put on the request
        let bodyParameters = {
            patientId: req.body.pid
        }
        
        console.log("putting the axios request now  ... ", 
            process.env.BLOCKCHAIN_URL1, bodyParameters)
        
        let bc_res = await axios.post(
            urlparse.resolve(process.env.BLOCKCHAIN_URL1, "/risk"),
            bodyParameters, {});
        if (bc_res.data){
            let data = bc_res.data;
            // Resposne from the remote end point
            // data is json sent
            console.log("Axios response: ", data)
            return res.send(data)
        }
    }catch(e){
        console.log("axios error")
        // axiox error
        if(e.response){
            if (e.response.status){
                console.log("Error Code: ", e.response.status)
            }
        }else
            console.log(e)
    }

    return res.send({
        error: true,
        msg: "Error Computing the advice for docter"
    })
}
